import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "ClassOrbit | Find your next classroom",
  description: "Discover and book coaching programmes near you."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
