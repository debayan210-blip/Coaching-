'use client';

import { useMemo, useState } from "react";
import { Search, MapPin, Star, Clock3, Users, BookOpen, GraduationCap, LayoutDashboard, Building2, CalendarCheck, ShieldCheck, Menu, X, ArrowRight, SlidersHorizontal, CheckCircle2, IndianRupee, Plus, Bell, ChevronDown } from "lucide-react";

type Course = {
  id: number; centre: string; title: string; category: string; area: string;
  city: string; fee: number; duration: string; rating: number; reviews: number;
  seats: number; mode: string; tag: string; color: string; initials: string;
};
const courses: Course[] = [
  { id: 1, centre: "Aakash Learning Hub", title: "NEET 2027: Classroom Programme", category: "NEET", area: "Salt Lake", city: "Kolkata", fee: 7200, duration: "12 months", rating: 4.8, reviews: 324, seats: 8, mode: "Offline", tag: "Popular", color: "#e7edff", initials: "AL" },
  { id: 2, centre: "Prime JEE Academy", title: "JEE Main + Advanced Foundation", category: "JEE", area: "Ballygunge", city: "Kolkata", fee: 8500, duration: "12 months", rating: 4.7, reviews: 218, seats: 5, mode: "Offline", tag: "Few seats left", color: "#fff0df", initials: "PJ" },
  { id: 3, centre: "CareerEdge Institute", title: "CAT 2027 Complete Preparation", category: "CAT", area: "Park Street", city: "Kolkata", fee: 5500, duration: "9 months", rating: 4.6, reviews: 186, seats: 14, mode: "Hybrid", tag: "New batch", color: "#e4f7ef", initials: "CE" },
  { id: 4, centre: "Bright Future Classes", title: "CBSE Class 10: Maths + Science", category: "K-12", area: "New Town", city: "Kolkata", fee: 3200, duration: "10 months", rating: 4.9, reviews: 142, seats: 11, mode: "Offline", tag: "Top rated", color: "#f4e9ff", initials: "BF" },
  { id: 5, centre: "Lexicon Law Prep", title: "CLAT 2027 Intensive Course", category: "CLAT", area: "Gariahat", city: "Kolkata", fee: 4800, duration: "8 months", rating: 4.5, reviews: 97, seats: 9, mode: "Hybrid", tag: "New batch", color: "#ffe8ed", initials: "LL" },
  { id: 6, centre: "GateCraft Academy", title: "GATE Computer Science 2027", category: "GATE", area: "Sector V", city: "Kolkata", fee: 6200, duration: "10 months", rating: 4.7, reviews: 111, seats: 6, mode: "Online", tag: "Few seats left", color: "#e5f3ff", initials: "GC" }
];
const categories = ["All", "K-12", "NEET", "JEE", "CAT", "CLAT", "GATE", "Other"];

export default function Home() {
  const [tab, setTab] = useState("Discover");
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [area, setArea] = useState("All areas");
  const [selected, setSelected] = useState<Course | null>(null);
  const [bookings, setBookings] = useState<{course: Course; months: number; status: string}[]>([]);
  const [notice, setNotice] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [centreSeats, setCentreSeats] = useState(8);
  const [showAll, setShowAll] = useState(false);

  const filtered = useMemo(() => courses.filter(c => {
    const matchCategory = category === "All" || c.category === category || (category === "Other" && !["K-12","NEET","JEE","CAT","CLAT","GATE"].includes(c.category));
    const q = query.toLowerCase();
    const matchQuery = !q || [c.title,c.centre,c.category,c.area].some(v => v.toLowerCase().includes(q));
    const matchArea = area === "All areas" || c.area === area;
    return matchCategory && matchQuery && matchArea;
  }), [category, query, area]);

  const book = (course: Course) => {
    setBookings(prev => [...prev, {course, months: 6, status: "Request submitted"}]);
    setSelected(null);
    setNotice("Booking request submitted! The centre will confirm your seat.");
    setTab("My bookings");
    setTimeout(() => setNotice(""), 4500);
  };
  const nav = [
    {name:"Discover", icon:Search}, {name:"My bookings", icon:CalendarCheck},
    {name:"For centres", icon:Building2}, {name:"Admin", icon:LayoutDashboard}
  ];

  return <main className="min-h-screen">
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 lg:px-8">
        <button className="flex items-center gap-2" onClick={() => setTab("Discover")}>
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-white"><GraduationCap size={23}/></span>
          <span className="text-left"><span className="block text-lg font-extrabold tracking-tight text-ink">ClassOrbit</span><span className="block text-[10px] font-semibold uppercase tracking-[.18em] text-slate-400">Learn. Choose. Grow.</span></span>
        </button>
        <nav className="hidden items-center gap-1 md:flex">
          {nav.map(n => <button key={n.name} onClick={() => setTab(n.name)} className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold ${tab===n.name?"bg-blue-50 text-brand":"text-slate-500 hover:bg-slate-50"}`}><n.icon size={16}/>{n.name}</button>)}
        </nav>
        <div className="hidden items-center gap-3 md:flex"><button className="relative rounded-full p-2 text-slate-500 hover:bg-slate-100"><Bell size={19}/><i className="absolute right-2 top-2 h-2 w-2 rounded-full bg-orange-500"/></button><button className="flex items-center gap-2 rounded-full border border-slate-200 py-1 pl-1 pr-3"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-100 text-xs font-bold text-orange-700">DD</span><span className="text-sm font-semibold">Student</span><ChevronDown size={14}/></button></div>
        <button className="rounded-lg p-2 md:hidden" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu?<X/>:<Menu/>}</button>
      </div>
      {mobileMenu && <div className="border-t bg-white p-3 md:hidden">{nav.map(n=><button key={n.name} onClick={()=>{setTab(n.name);setMobileMenu(false)}} className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left text-sm font-semibold"><n.icon size={17}/>{n.name}</button>)}</div>}
    </header>

    <div className="mx-auto max-w-7xl px-4 py-7 lg:px-8">
      {notice && <div className="mb-5 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm font-medium text-emerald-800"><CheckCircle2 size={18}/>{notice}</div>}

      {tab==="Discover" && <>
        <section className="relative overflow-hidden rounded-3xl bg-ink px-6 py-9 text-white md:px-10 md:py-12">
          <div className="relative z-10 max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-semibold text-blue-100"><span className="h-2 w-2 rounded-full bg-emerald-400"/> Your learning journey starts here</div>
            <h1 className="max-w-xl text-3xl font-extrabold leading-tight tracking-tight md:text-5xl">Find the right coaching. <span className="text-blue-300">Book your future.</span></h1>
            <p className="mt-4 max-w-lg text-sm leading-6 text-slate-300 md:text-base">Explore trusted institutes, compare programmes and reserve your seat — all in one place.</p>
            <div className="mt-7 grid gap-2 rounded-2xl bg-white p-2 shadow-xl md:grid-cols-[1fr_190px_auto]">
              <div className="flex items-center gap-3 px-3"><Search className="shrink-0 text-slate-400" size={20}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Course, exam or institute..." className="w-full py-3 text-sm text-slate-800 outline-none placeholder:text-slate-400"/></div>
              <div className="flex items-center gap-2 border-t px-3 md:border-l md:border-t-0"><MapPin size={18} className="text-slate-400"/><select value={area} onChange={e=>setArea(e.target.value)} className="w-full bg-transparent py-3 text-sm text-slate-700 outline-none"><option>All areas</option>{["Salt Lake","Ballygunge","Park Street","New Town","Gariahat","Sector V"].map(a=><option key={a}>{a}</option>)}</select></div>
              <button onClick={()=>document.getElementById("courses")?.scrollIntoView({behavior:"smooth"})} className="rounded-xl bg-brand px-6 py-3 text-sm font-bold text-white hover:bg-blue-700">Search courses</button>
            </div>
          </div>
          <div className="pointer-events-none absolute -right-16 -top-24 h-96 w-96 rounded-full border-[45px] border-white/5"/><div className="pointer-events-none absolute -bottom-40 right-28 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl"/>
          <div className="absolute bottom-7 right-9 hidden rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur md:block"><div className="text-3xl font-extrabold">15%</div><div className="text-xs text-blue-100">More choice. One platform.</div></div>
        </section>

        <section className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
          {[["1,200+","Courses listed"],["350+","Coaching partners"],["4.8/5","Student experience"],["6 months","Minimum booking"]].map(([v,l])=><div key={l} className="rounded-2xl border border-slate-200 bg-white p-4"><div className="text-xl font-extrabold text-ink md:text-2xl">{v}</div><div className="mt-1 text-xs font-medium text-slate-500">{l}</div></div>)}
        </section>

        <section id="courses" className="mt-10">
          <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-brand">Explore programmes</p><h2 className="mt-1 text-2xl font-extrabold tracking-tight text-ink">Find your perfect course</h2><p className="mt-1 text-sm text-slate-500">Curated options from coaching partners</p></div><button onClick={()=>{setCategory("All");setArea("All areas");setQuery("")}} className="flex items-center gap-2 text-sm font-semibold text-brand"><SlidersHorizontal size={16}/> Clear filters</button></div>
          <div className="mt-5 flex gap-2 overflow-x-auto pb-2">{categories.map(c=><button key={c} onClick={()=>setCategory(c)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold ${category===c?"bg-ink text-white":"border border-slate-200 bg-white text-slate-600 hover:border-blue-300"}`}>{c}</button>)}</div>
          <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.slice(0,showAll?99:6).map(c=><article key={c.id} className="group overflow-hidden rounded-2xl border border-slate-200 bg-white transition hover:-translate-y-1 hover:shadow-lg">
              <div className="flex h-32 items-center justify-between p-5" style={{background:c.color}}><div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-lg font-extrabold text-ink shadow-sm">{c.initials}</div><span className="rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-bold text-slate-700">{c.tag}</span></div>
              <div className="p-5"><div className="flex items-center justify-between gap-2"><span className="text-xs font-semibold text-slate-500">{c.centre}</span><span className="flex items-center gap-1 text-xs font-bold text-amber-600"><Star size={13} fill="currentColor"/>{c.rating} <span className="font-normal text-slate-400">({c.reviews})</span></span></div><h3 className="mt-2 min-h-12 text-base font-extrabold leading-6 text-ink">{c.title}</h3><div className="mt-3 flex flex-wrap gap-3 text-xs text-slate-500"><span className="flex items-center gap-1"><MapPin size={13}/>{c.area}, {c.city}</span><span className="flex items-center gap-1"><Clock3 size={13}/>{c.duration}</span></div><div className="mt-4 flex items-end justify-between border-t border-slate-100 pt-4"><div><div className="text-[11px] text-slate-400">Monthly fee from</div><div className="text-xl font-extrabold text-ink">₹{c.fee.toLocaleString("en-IN")}<span className="text-xs font-medium text-slate-400">/mo</span></div><div className="mt-1 text-[11px] font-semibold text-emerald-700">{c.seats} seats available · {c.mode}</div></div><button onClick={()=>setSelected(c)} className="rounded-xl bg-brand px-4 py-2.5 text-xs font-bold text-white hover:bg-blue-700">View details <ArrowRight className="ml-1 inline" size={13}/></button></div></div>
            </article>)}
          </div>
          {filtered.length===0 && <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-slate-500">No courses match those filters. Try another search.</div>}
          {filtered.length>6 && <div className="mt-6 text-center"><button onClick={()=>setShowAll(!showAll)} className="rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-bold text-ink">{showAll?"Show fewer":"View all courses"}</button></div>}
        </section>
      </>}

      {tab==="My bookings" && <section><p className="text-xs font-bold uppercase tracking-widest text-brand">Student dashboard</p><h1 className="mt-2 text-3xl font-extrabold text-ink">My bookings</h1><p className="mt-2 text-sm text-slate-500">Track your course requests and seat confirmations.</p>
        {bookings.length===0?<div className="mt-7 rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center"><CalendarCheck className="mx-auto text-slate-300" size={36}/><h3 className="mt-3 font-bold text-ink">No bookings yet</h3><p className="mt-1 text-sm text-slate-500">Explore courses and reserve your first seat.</p><button onClick={()=>setTab("Discover")} className="mt-5 rounded-xl bg-brand px-5 py-3 text-sm font-bold text-white">Explore courses</button></div>:<div className="mt-6 grid gap-4">{bookings.map((b,i)=><div key={i} className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border bg-white p-5"><div><div className="text-xs font-semibold text-slate-400">{b.course.centre}</div><div className="mt-1 font-bold text-ink">{b.course.title}</div><div className="mt-2 text-xs text-slate-500">{b.months} months · ₹{(b.course.fee*b.months).toLocaleString("en-IN")} total demo value</div></div><span className="rounded-full bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-700">{b.status}</span></div>)}</div>}
      </section>}

      {tab==="For centres" && <section><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-widest text-brand">Partner portal</p><h1 className="mt-2 text-3xl font-extrabold text-ink">Centre dashboard</h1><p className="mt-2 text-sm text-slate-500">Manage your listings and keep seat availability up to date.</p></div><button className="rounded-xl bg-brand px-4 py-3 text-sm font-bold text-white"><Plus className="mr-1 inline" size={16}/> Add a course</button></div>
        <div className="mt-7 grid gap-4 sm:grid-cols-3">{[["Active courses","12"],["Booking requests","28"],["Profile views","1,840"]].map(([l,v])=><div key={l} className="rounded-2xl border bg-white p-5"><div className="text-sm text-slate-500">{l}</div><div className="mt-2 text-3xl font-extrabold text-ink">{v}</div></div>)}</div>
        <div className="mt-6 rounded-2xl border bg-white p-5"><div className="flex items-center justify-between"><div><h3 className="font-extrabold text-ink">NEET 2027 Classroom Programme</h3><p className="mt-1 text-xs text-slate-500">Aakash Learning Hub · Salt Lake</p></div><span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">Published</span></div><div className="mt-5 flex flex-wrap items-center justify-between gap-3"><div><div className="text-xs text-slate-500">Available seats</div><div className="text-2xl font-extrabold text-ink">{centreSeats}</div></div><div className="flex items-center gap-2"><button onClick={()=>setCentreSeats(Math.max(0,centreSeats-1))} className="h-10 w-10 rounded-lg border font-bold">−</button><button onClick={()=>setCentreSeats(centreSeats+1)} className="h-10 w-10 rounded-lg border font-bold">+</button><span className="ml-2 text-xs text-slate-500">Update inventory</span></div></div></div>
      </section>}

      {tab==="Admin" && <section><p className="text-xs font-bold uppercase tracking-widest text-brand">Platform operations</p><h1 className="mt-2 text-3xl font-extrabold text-ink">Admin overview</h1><p className="mt-2 text-sm text-slate-500">Illustrative marketplace metrics — demo data only.</p>
        <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[["Gross booking value","₹24.8L","+12.4%"],["Platform commission","₹3.72L","15% rate"],["Partner centres","350","+28 this month"],["Booking requests","1,240","+8.2%"]].map(([l,v,d])=><div key={l} className="rounded-2xl border bg-white p-5"><div className="text-xs font-semibold text-slate-500">{l}</div><div className="mt-2 text-2xl font-extrabold text-ink">{v}</div><div className="mt-2 text-xs font-semibold text-emerald-700">{d}</div></div>)}</div>
        <div className="mt-6 grid gap-5 lg:grid-cols-2"><div className="rounded-2xl border bg-white p-5"><h3 className="font-extrabold text-ink">Marketplace rules</h3><div className="mt-4 space-y-3 text-sm">{[["Minimum booking duration","6 months"],["Platform commission","15%"],["Free centre onboarding","First 10,000 centres"],["Inventory","Centre-managed"]].map(([a,b])=><div key={a} className="flex justify-between border-b pb-3"><span className="text-slate-500">{a}</span><strong>{b}</strong></div>)}</div></div><div className="rounded-2xl border bg-white p-5"><h3 className="font-extrabold text-ink">Recent activity</h3><div className="mt-4 space-y-4">{["New partner application · Kolkata","Booking request · NEET 2027","Seat inventory updated · Salt Lake","New course listed · CAT 2027"].map((a,i)=><div key={a} className="flex items-center gap-3 text-sm"><span className="h-2 w-2 rounded-full bg-brand"/><span className="text-slate-600">{a}</span><span className="ml-auto text-xs text-slate-400">{i+1}h ago</span></div>)}</div></div></div>
      </section>}
      <footer className="mt-14 border-t border-slate-200 py-6 text-center text-xs text-slate-400">© 2026 ClassOrbit · Demo marketplace prototype · Built for learning access</footer>
    </div>

    {selected && <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/50 p-0 sm:items-center sm:p-4" onClick={()=>setSelected(null)}><div className="w-full max-w-lg rounded-t-3xl bg-white p-6 shadow-2xl sm:rounded-3xl" onClick={e=>e.stopPropagation()}><div className="flex items-start justify-between"><div><span className="text-xs font-bold uppercase tracking-wider text-brand">{selected.category} programme</span><h2 className="mt-2 text-xl font-extrabold text-ink">{selected.title}</h2><p className="mt-1 text-sm text-slate-500">{selected.centre} · {selected.area}</p></div><button onClick={()=>setSelected(null)} className="rounded-full bg-slate-100 p-2"><X size={18}/></button></div><div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">Monthly fee</div><div className="mt-1 text-lg font-extrabold">₹{selected.fee.toLocaleString("en-IN")}</div></div><div className="rounded-xl bg-slate-50 p-3"><div className="text-xs text-slate-500">Available seats</div><div className="mt-1 text-lg font-extrabold">{selected.seats}</div></div></div><div className="mt-4 rounded-xl border border-blue-100 bg-blue-50 p-4"><div className="text-xs font-bold text-blue-800">6-month minimum booking</div><div className="mt-1 text-2xl font-extrabold text-ink">₹{(selected.fee*6).toLocaleString("en-IN")}<span className="text-xs font-medium text-slate-500"> total course booking value</span></div><div className="mt-1 text-xs text-slate-500">Final fee and seat confirmation are subject to centre approval.</div></div><button onClick={()=>book(selected)} className="mt-5 w-full rounded-xl bg-brand py-3.5 text-sm font-bold text-white hover:bg-blue-700">Request a seat <ArrowRight className="ml-1 inline" size={16}/></button><p className="mt-3 text-center text-[11px] text-slate-400">Demo only · No payment will be collected</p></div></div>}
  </main>;
}
